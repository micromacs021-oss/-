package com.example.harmonia

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.*
import kotlin.math.abs
import kotlin.math.roundToInt

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { HarmoniaApp() }
    }
}

private data class Note(val bar: Int, val beat: Float, val midi: Int, val dur: Float, val voice: String)
private data class Chord(val root: Int, val pcs: List<Int>, val symbol: String, val function: String, val degree: Int)
private data class HarmEvent(val bar: Int, val beat: Float, val pcs: Set<Int>)
private data class Voicing(val s: Int, val a: Int, val t: Int, val b: Int, val chord: Chord)

private val pitchNames = listOf("До", "До♯", "Ре", "Ми♭", "Ми", "Фа", "Фа♯", "Соль", "Ля♭", "Ля", "Си♭", "Си")
private val keyRoots = mapOf("До мажор" to 0, "Соль мажор" to 7, "Ре мажор" to 2, "Фа мажор" to 5, "Си♭ мажор" to 10, "Ля♭ мажор" to 8)
private val scaleSteps = listOf(0, 2, 4, 5, 7, 9, 11)

@Composable
fun HarmoniaApp() {
    var mode by remember { mutableStateOf("Мелодия") }
    var key by remember { mutableStateOf("До мажор") }
    var meter by remember { mutableStateOf("4/4") }
    var duration by remember { mutableFloatStateOf(1f) }
    var bars by remember { mutableIntStateOf(4) }
    var notes by remember { mutableStateOf(listOf<Note>()) }
    var result by remember { mutableStateOf(listOf<List<Voicing>>()) }
    var message by remember { mutableStateOf("Коснись нотного стана, чтобы поставить ноту.") }
    val beats = meter.substringBefore('/').toInt() * (4f / meter.substringAfter('/').toInt())
    val dark = Color(0xFF11151D)
    val panel = Color(0xFF1C2430)
    val mint = Color(0xFF9DD8C8)

    MaterialTheme(colorScheme = darkColorScheme(primary = mint, background = dark, surface = panel)) {
        Column(Modifier.fillMaxSize().background(dark).verticalScroll(rememberScrollState()).padding(12.dp)) {
            Text("ГАРМОНИЯ", color = Color.White, fontSize = 23.sp, fontWeight = FontWeight.Bold)
            Text("Нотный ввод · четырёхголосная гармонизация", color = Color.LightGray, fontSize = 12.sp)
            Spacer(Modifier.height(12.dp))
            Card(colors = CardDefaults.cardColors(containerColor = panel)) {
                Column(Modifier.padding(12.dp)) {
                    Text("Ввод задачи", color = Color.White, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(8.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Choice("Голос", mode, listOf("Мелодия", "Бас")) { mode = it; notes = notes.filter { n -> n.voice == it }; result = emptyList() }
                        Choice("Тональность", key, keyRoots.keys.toList()) { key = it; result = emptyList() }
                    }
                    Spacer(Modifier.height(8.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                        Choice("Размер", meter, listOf("4/4", "3/4", "2/4", "6/8")) { meter = it; result = emptyList() }
                        Choice("Длительность", if(duration==0.5f) "⅛" else if(duration==1f) "¼" else if(duration==2f) "½" else "1/1",
                            listOf("⅛","¼","½","1/1")) { duration = when(it){"⅛"->0.5f;"¼"->1f;"½"->2f;else->4f} }
                    }
                    Spacer(Modifier.height(8.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("Такты: $bars", color = Color.White)
                        Spacer(Modifier.width(10.dp))
                        OutlinedButton(onClick={ if(bars>1){bars--;notes=notes.filter{it.bar<bars};result= emptyList()} }) { Text("−") }
                        OutlinedButton(onClick={ if(bars<16) bars++ }) { Text("+") }
                        Spacer(Modifier.weight(1f))
                        TextButton(onClick={notes= emptyList();result= emptyList();message="Ввод очищен."}) { Text("Очистить") }
                    }
                    Spacer(Modifier.height(8.dp))
                    StaffEditor(notes, mode, bars, beats, onAdd = { n ->
                        if (n.beat + duration > beats + 0.001f) message = "Эта длительность не помещается в такт. Выбери меньшую."
                        else if (notes.none { it.bar==n.bar && abs(it.beat-n.beat)<0.01f && it.voice==mode }) {
                            notes = (notes + n.copy(dur=duration)).sortedWith(compareBy<Note>{it.bar}.thenBy{it.beat})
                            result = emptyList()
                            message = "Нота добавлена: ${pitchNames[n.midi.mod(12)]}${n.midi/12-1}, такт ${n.bar+1}."
                        }
                    })
                    Text(message, color = Color(0xFFB9C6D5), fontSize = 12.sp)
                    Spacer(Modifier.height(8.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(onClick={ if(notes.isNotEmpty()) notes=notes.dropLast(1); result=emptyList() }) { Text("Отменить") }
                        Button(onClick={ result = Harmonizer.solve(notes, mode, key, bars, beats); message = if(result.isEmpty()) "Добавь ноты перед решением." else "Готово: найдено ${result.size} варианта(ов)." }) { Text("Решить задачу") }
                    }
                }
            }
            Spacer(Modifier.height(12.dp))
            Text("Результаты", color=Color.White, fontSize=18.sp, fontWeight=FontWeight.Bold)
            if(result.isEmpty()) Text("Здесь появятся варианты гармонизации.", color=Color.LightGray, fontSize=13.sp)
            result.forEachIndexed { i, variant ->
                Spacer(Modifier.height(8.dp))
                Card(colors=CardDefaults.cardColors(containerColor=panel)) {
                    Column(Modifier.padding(10.dp)) {
                        Text("Вариант ${i+1}", color=mint, fontWeight=FontWeight.Bold)
                        Text("Сопрано · альт · тенор · бас", color=Color.LightGray, fontSize=11.sp)
                        StaffResult(variant, bars, beats, notes, mode)
                        variant.forEach { v ->
                            Text("такт ${v.chord.let { variant.indexOf(v)+1 }}: ${v.chord.symbol} — ${v.chord.function}; S ${pitchNames[v.s.mod(12)]}, A ${pitchNames[v.a.mod(12)]}, T ${pitchNames[v.t.mod(12)]}, B ${pitchNames[v.b.mod(12)]}",
                                color=Color.White, fontSize=11.sp)
                        }
                    }
                }
            }
            Spacer(Modifier.height(16.dp))
            Text("Примечание: это начальный учебный решатель диатонической гармонии. Он строит варианты четырёхголосных аккордов с ограничением диапазонов и проверкой параллельных квинт/октав между соседними позициями. Он пока не покрывает весь курс Абызовой, хроматику, модуляции и все специальные кадансовые модели.", color=Color(0xFFB9C6D5), fontSize=11.sp)
        }
    }
}

@Composable
private fun Choice(label: String, value: String, options: List<String>, onChange:(String)->Unit) {
    var expanded by remember { mutableStateOf(false) }
    Column(Modifier.width(150.dp)) {
        Text(label, color=Color.LightGray, fontSize=11.sp)
        Box {
            OutlinedButton(onClick={expanded=true}, modifier=Modifier.fillMaxWidth()) { Text(value, maxLines=1, fontSize=11.sp) }
            DropdownMenu(expanded=expanded, onDismissRequest={expanded=false}) {
                options.forEach { DropdownMenuItem(text={Text(it)}, onClick={onChange.also { }; { onChange(it); expanded=false }) }
            }
        }
    }
}

@Composable
private fun StaffEditor(notes: List<Note>, mode:String, bars:Int, beats:Float, onAdd:(Note)->Unit) {
    val totalWidth = maxOf(620f, bars*150f+45f)
    var preview by remember { mutableStateOf<Pair<Float,Float>?>(null) }
    Column {
        Row(Modifier.horizontalScroll(rememberScrollState())) {
            Canvas(Modifier.width(totalWidth.dp).height(250.dp).background(Color(0xFFF9F7F0), RoundedCornerShape(8.dp))
                .pointerInput(notes,mode,bars,beats) {
                    detectTapGestures { p ->
                        val x=p.x/ density
                        val y=p.y/ density
                        val left=48f
                        val barW=(totalWidth-60f)/bars
                        val bar=((x-left)/barW).toInt()
                        if(bar in 0 until bars) {
                            val beat=(((x-left)/barW-bar)*beats*2).roundToInt()/2f
                            val baseY=if(mode=="Мелодия") 91f else 207f
                            val step=((baseY-y)/5.5f).roundToInt()
                            val baseMidi=if(mode=="Мелодия")64 else 43
                            val midi=diatonicStepToMidi(baseMidi+step)
                            onAdd(Note(bar,beat,midi,1f,mode))
                        }
                    }
                }) {
                val left=48f; val barW=(totalWidth-60f)/bars
                val top=55f
                for(i in 0..4) {
                    drawLine(Color.DarkGray, Offset(left,top+i*11f), Offset(size.width-10f,top+i*11f),1f)
                    drawLine(Color.DarkGray, Offset(left,171f+i*11f), Offset(size.width-10f,171f+i*11f),1f)
                }
                drawContext.canvas.nativeCanvas.drawText("𝄞", 5f, 111f, android.graphics.Paint().apply { textSize=45f; color=android.graphics.Color.BLACK })
                drawContext.canvas.nativeCanvas.drawText("𝄢", 5f, 224f, android.graphics.Paint().apply { textSize=39f; color=android.graphics.Color.BLACK })
                for(b in 0..bars) {
                    val x=left+b*barW
                    drawLine(Color.Gray,Offset(x,top),Offset(x,215f),1f)
                }
                notes.forEach { n ->
                    val x=left+(n.bar+n.beat/beats)*barW
                    val y=if(n.voice=="Мелодия") 91f-(diatonicStepsFromMidi(64,n.midi))*5.5f else 207f-(diatonicStepsFromMidi(43,n.midi))*5.5f
                    drawOval(Color.Black, topLeft=Offset(x-6,y-4), size=androidx.compose.ui.geometry.Size(12f,8f))
                    drawLine(Color.Black,Offset(x+5,y),Offset(x+5,y-27),1.5f)
                }
            }
        }
        Text("Верхний стан: скрипичный ключ · нижний стан: басовый ключ. Прокручивай по горизонтали, если тактов много.", color=Color.LightGray, fontSize=10.sp)
    }
}

@Composable
private fun StaffResult(chords:List<Voicing>, bars:Int, beats:Float, input:List<Note>, mode:String) {
    val width=maxOf(620f,bars*150f+45f)
    Row(Modifier.horizontalScroll(rememberScrollState())) {
        Canvas(Modifier.width(width.dp).height(250.dp).background(Color(0xFFF9F7F0),RoundedCornerShape(8.dp))) {
            val left=48f;val barW=(width-60f)/bars;val top=55f
            for(i in 0..4){drawLine(Color.DarkGray,Offset(left,top+i*11f),Offset(size.width-10f,top+i*11f),1f);drawLine(Color.DarkGray,Offset(left,171f+i*11f),Offset(size.width-10f,171f+i*11f),1f)}
            for(b in 0..bars)drawLine(Color.Gray,Offset(left+b*barW,top),Offset(left+b*barW,226f),1f)
            val paint=android.graphics.Paint().apply{color=android.graphics.Color.BLACK;textSize=38f}
            drawContext.canvas.nativeCanvas.drawText("𝄞",5f,111f,paint);drawContext.canvas.nativeCanvas.drawText("𝄢",5f,224f,paint)
            input.forEach { n ->
                val x=left+(n.bar+n.beat/beats)*barW
                val y=if(n.voice=="Мелодия")91f-diatonicStepsFromMidi(64,n.midi)*5.5f else 207f-diatonicStepsFromMidi(43,n.midi)*5.5f
                drawOval(Color.Black,Offset(x-6,y-4),androidx.compose.ui.geometry.Size(12f,8f))
            }
            chords.forEachIndexed { i,v ->
                val x=left+(i.toFloat()/maxOf(1,chords.size))*barW*bars+12f
                val positions=listOf(v.s to 91f,v.a to 112f,v.t to 187f,v.b to 207f)
                positions.forEach { (m,base) ->
                    val y=base-diatonicStepsFromMidi(if(base<130f)64 else 43,m)*5.5f
                    drawOval(Color(0xFF176B58),Offset(x-5,y-3),androidx.compose.ui.geometry.Size(10f,7f))
                }
            }
        }
    }
}

private fun diatonicStepToMidi(step:Int):Int {
    val octave=Math.floorDiv(step,7)
    val degree=Math.floorMod(step,7)
    return (octave+1)*12+listOf(0,2,4,5,7,9,11)[degree]
}
private fun diatonicStepsFromMidi(base:Int, target:Int):Int {
    fun index(m:Int):Int {
        val pc=m.mod(12)
        val map=mapOf(0 to 0,2 to 1,4 to 2,5 to 3,7 to 4,9 to 5,11 to 6)
        val deg=map[pc] ?: listOf(0,2,4,5,7,9,11).indices.minBy { abs(listOf(0,2,4,5,7,9,11)[it]-pc) }
        return (m/12-1)*7+deg
    }
    return index(target)-index(base)
}

private object Harmonizer {
    fun solve(notes:List<Note>, mode:String, key:String, bars:Int, beats:Float):List<List<Voicing>> {
        if(notes.isEmpty()) return emptyList()
        val tonic=keyRoots[key] ?: 0
        val scale=scaleSteps.map { (it+tonic)%12 }
        val triadDegrees=listOf(0,1,2,3,4,5,6)
        val qualities=listOf("", "m", "m", "", "", "m", "dim")
        val functions=listOf("T", "S", "T", "S", "D", "T", "D")
        val chords=triadDegrees.map { d ->
            val root=scale[d]
            val pcs=listOf(scale[d],scale[(d+2)%7],scale[(d+4)%7])
            Chord(root,pcs,pitchNames[root]+qualities[d],functions[d],d)
        }
        val events=mutableListOf<HarmEvent>()
        for(bar in 0 until bars) for(beat in 0 until beats.toInt()) {
            val active=notes.filter { it.bar==bar && it.beat<=beat+.001f && it.beat+it.dur>beat+.001f }
            if(active.isNotEmpty()) events.add(HarmEvent(bar,beat.toFloat(),active.map{it.midi.mod(12)}.toSet()))
        }
        if(events.isEmpty()) return emptyList()
        val candidates=events.map { ev ->
            chords.filter { c -> ev.pcs.any { it in c.pcs } }.ifEmpty { chords }
        }
        val variants=mutableListOf<List<Voicing>>()
        for(variant in 0..2) {
            var prev:Voicing?=null
            val path=mutableListOf<Voicing>()
            events.forEachIndexed { idx, ev ->
                val ranked=candidates[idx].flatMap { c -> voicings(c, tonic) }.map { v ->
                    var cost=0
                    val matching=ev.pcs.count { it in v.chord.pcs }
                    cost += (ev.pcs.size-matching)*18
                    if(prev!=null) {
                        val p=prev!!
                        cost += abs(v.s-p.s)+abs(v.a-p.a)+abs(v.t-p.t)+abs(v.b-p.b)
                        if(parallelPerfect(p,v)) cost+=1000
                        if(p.chord.function=="D" && v.chord.function=="T") cost-=12
                        if(p.chord.function=="S" && v.chord.function=="D") cost-=8
                    }
                    if(idx==events.lastIndex) {
                        if(v.chord.function=="T") cost-=18 else cost+=8
                    }
                    cost += ((v.chord.degree*5+variant*7+idx*3)%9)*2
                    v to cost
                }.sortedBy { it.second }
                val pick=ranked.firstOrNull()?.first ?: return@forEachIndexed
                path.add(pick);prev=pick
            }
            if(path.isNotEmpty()) variants.add(path)
        }
        return variants
    }

    private fun voicings(c:Chord, tonic:Int):List<Voicing> {
        val pcs=c.pcs
        val out=mutableListOf<Voicing>()
        for(b in  bassCandidates(c)) for(t in 48..59) if(t.mod(12) in pcs)
            for(a in 55..76) if(a.mod(12) in pcs && a>t)
                for(s in 60..81) if(s.mod(12) in pcs && s>a) {
                    if(s-a>12 || a-t>12 || t-b>19) continue
                    val counts=listOf(s,a,t,b).groupingBy{it.mod(12)}.eachCount()
                    if(counts.values.any{it>2}) continue
                    out.add(Voicing(s,a,t,b,c))
                    if(out.size>180) return out
                }
        return out
    }
    private fun bassCandidates(c:Chord)= (36..52).filter { it.mod(12) in c.pcs }
    private fun parallelPerfect(p:Voicing,n:Voicing):Boolean {
        val old=listOf(p.s,p.a,p.t,p.b);val now=listOf(n.s,n.a,n.t,n.b)
        for(i in 0..2) for(j in i+1..3) {
            val a=(old[i]-old[j]).mod(12);val b=(now[i]-now[j]).mod(12)
            if((a==0||a==7)&&(b==0||b==7)&&((now[i]-old[i])*(now[j]-old[j])>0)) return true
        }
        return false
    }
}
